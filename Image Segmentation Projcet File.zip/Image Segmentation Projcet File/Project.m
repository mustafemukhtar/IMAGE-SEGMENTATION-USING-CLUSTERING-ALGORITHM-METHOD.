
  % Read the source RGB image
  x = imread('balloons.jpeg');
  figure; imshow(x)
  [r,c,s] = size(x);
  
  %initialize storage for each sample region
  
  classes = { 'Orange' , 'Blue', 'Yellow' , 'Green', 'Background' };
  nClasses = length(classes);
  sample_regions = false([r c nClasses]);
  
  %select each sample region
  
  f = figure;
  for count = 1:nClasses
      set(f, 'name', ['select sample region for ' classes{count}]);
      sample_regions(:,:,count) = roipoly(x);
  end
 close(f);
  
  %Display Sample Regions
  
  for count = 1:nClasses
      figure
      imshow(sample_regions(:,:,count))
      title(['sample region for ' classes(count)]);
  end
  
  % Convert the RGB image into an L*a*b* image \
  
  
 cform = makecform('srgb2lab');
 lab_x = applycform(x,cform);
 
 % Calculate the mean 'a*' and 'b*' value for each region of intersr (ROI) area
 
 a= lab_x(:,:,2);
 b= lab_x(:,:,3);
 color_markers =  zeros([nClasses,2]);
 
 for count=1:nClasses
     color_markers(count,1) = mean2(a(sample_regions(:,:,count)));
     color_markers(count,2) = mean2(b(sample_regions(:,:,count)));
 end
 
 %% step 3: Classify each pixel using the nearest neighbor rule
 % Each color marker now has an 'a*' and 'b*' value. we can classify each pixel
 % in the |lab_x| image by calculating the Euclidean distance between that
 % pixel and each color marker. The smallest distance will tell us that the 
 % pixel most closely matches that color marker. For exmaple, if the
 % distance between a pixel and the Orange color marker is the smallest, then
 % the pixel would be labeled as a Orange pixel.
 

color_labels = 0:nClasses-1;
a = double(a);
b = double(b);
% distance = zeros([size(a), nClasses]);

% % perform classification

% Vectorized pixel classification
distance = zeros([r, c, nClasses]);
for count = 1:nClasses
    distance(:,:,count) = sqrt((a - color_markers(count,1)).^2 + (b - color_markers(count,2)).^2);
end

[~, label] = min(distance,[],3);
label = label - 1; % Adjust labels

% Optimized image coloring

colors = [0 0 255; 0 255 0; 0 255 255; 255 0 255; 255 255 255; 255 255 0];

% Generate colored image directly using indexing
y = zeros([r, c, 3]);
for ch = 1:3
    y(:,:,ch) = reshape(colors(label + 1, ch), [r, c]);
end

% Display the colored image
figure;
imshow(uint8(y));
colorbar;

% scatter plot with clear labels
plot_colors = {'r', 'g', 'b', 'm', 'y'}; % Update plot colors for readability

figure;
for count = 1:nClasses
    scatter(a(label == (count - 1)), b(label == (count - 1)), [], plot_colors{count}, 'filled');
    hold on;
end

title('Scatterplot of the segmented pixels in ''a*b*'' space');
xlabel('''a*'' values');
ylabel('''b*'' values');
legend(classes); % Added a legend for better understanding
